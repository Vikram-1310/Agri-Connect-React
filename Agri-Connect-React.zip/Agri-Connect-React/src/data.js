export const crops=[
{id:1,name:'Rice',season:'Kharif',duration:'120–150 days',soil:'Clay / alluvial',water:'High',description:'A major cereal crop grown in irrigated and rain-fed systems.',tips:'Use certified seed, manage field water and monitor pests.'},
{id:2,name:'Wheat',season:'Rabi',duration:'110–130 days',soil:'Well-drained loam',water:'Medium',description:'A staple cereal suited to cool growing conditions.',tips:'Sow at the recommended time and avoid excess irrigation near maturity.'},
{id:3,name:'Groundnut',season:'Kharif / Rabi',duration:'100–125 days',soil:'Sandy loam',water:'Medium',description:'An important oilseed and legume crop.',tips:'Avoid waterlogging and maintain good field drainage.'},
{id:4,name:'Tomato',season:'Regional',duration:'90–120 days',soil:'Fertile loam',water:'Medium',description:'A popular vegetable crop requiring regular monitoring.',tips:'Use staking where appropriate and remove diseased plant material.'},
{id:5,name:'Chickpea',season:'Rabi',duration:'100–120 days',soil:'Well-drained loam',water:'Low',description:'A pulse crop that can grow with relatively low water.',tips:'Avoid excessive irrigation and inspect for pod borer.'},
{id:6,name:'Maize',season:'Kharif / Rabi',duration:'90–120 days',soil:'Loam',water:'Medium',description:'A versatile cereal used for food, feed and industry.',tips:'Keep fields weed-free during early growth.'}
];
export const tips=[
{id:1,title:'Test your soil',category:'Soil health',body:'Get soil tested before choosing fertilisers. Follow recommendations for your crop and field.'},
{id:2,title:'Use quality seeds',category:'Crop planning',body:'Choose certified seeds suited to your region and sowing season.'},
{id:3,title:'Plan irrigation',category:'Water management',body:'Irrigate according to crop stage, soil moisture and local weather. Avoid waterlogging.'},
{id:4,title:'Monitor pests early',category:'Plant protection',body:'Inspect plants regularly and use integrated pest management with local expert advice.'},
{id:5,title:'Rotate crops',category:'Crop planning',body:'Rotate cereals with legumes where suitable to support soil health.'},
{id:6,title:'Keep farm records',category:'Farm management',body:'Record sowing dates, inputs, expenses and harvest quantities.'}
];
export const prices=[
{id:1,commodity:'Paddy',market:'Guntur',state:'Andhra Pradesh',min:2100,max:2450,date:'2026-10-28'},
{id:2,commodity:'Maize',market:'Vijayawada',state:'Andhra Pradesh',min:1900,max:2250,date:'2026-10-28'},
{id:3,commodity:'Groundnut',market:'Anantapur',state:'Andhra Pradesh',min:5600,max:6900,date:'2026-10-27'},
{id:4,commodity:'Chilli',market:'Guntur',state:'Andhra Pradesh',min:8500,max:14500,date:'2026-10-27'},
{id:5,commodity:'Tomato',market:'Madanapalle',state:'Andhra Pradesh',min:1200,max:2600,date:'2026-10-26'}
];
export const schemes=[
{id:1,name:'PM-KISAN',agency:'Government of India',description:'Income support for eligible farmer families, subject to scheme rules.',url:'https://pmkisan.gov.in/'},
{id:2,name:'Pradhan Mantri Fasal Bima Yojana',agency:'Ministry of Agriculture',description:'Crop insurance support for eligible farmers against specified risks.',url:'https://pmfby.gov.in/'},
{id:3,name:'Kisan Credit Card',agency:'Government of India',description:'Institutional credit facility for eligible agricultural and allied activities.',url:'https://www.myscheme.gov.in/'},
{id:4,name:'Soil Health Card',agency:'Department of Agriculture',description:'Soil testing and nutrient recommendations for balanced fertiliser use.',url:'https://soilhealth.dac.gov.in/'},
{id:5,name:'e-NAM',agency:'Ministry of Agriculture',description:'Online trading platform connecting agricultural markets.',url:'https://enam.gov.in/'}
];