# Agri Connect — React Edition

A responsive agriculture information platform built with React, Vite and CSS.

## Farmer features
- Farmer registration and login
- Dashboard and profile management
- Crop information and search
- Farming tips and search
- Market price reference table
- Live city weather through Open-Meteo (no API key)
- Agriculture scheme summaries and official links
- Logout

## Admin features
- Admin dashboard and registered farmer list
- Add, edit and delete crop information
- Add, edit and delete market price records
- Add, edit and delete farming tips
- Add, edit and delete scheme information

## Run the project
1. Install Node.js LTS.
2. Extract the ZIP and open this folder in VS Code.
3. In the terminal run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the localhost URL printed by Vite (usually http://localhost:5173).

Production build: `npm run build`

## Demo admin login
Email: `admin@agriconnect.in`
Password: `admin123`

Farmers can create their own accounts from the sign-up page.

## APIs and data
- Weather uses Open-Meteo geocoding and forecast endpoints; no API key is required.
- Crop guides, tips, schemes and market prices start from the bundled dataset in `src/data.js`.
- Market prices are sample/reference records, not live mandi quotations. Verify prices with the local mandi or official sources.
- Farmer accounts and admin changes are stored in browser Local Storage.

## Security note
This is a front-end college/demo prototype. Local Storage authentication and client-side admin credentials are not secure for production. A public deployment should use a secure backend, hashed passwords, server-side role checks and a database.

## Structure
`index.html`, `package.json`, `vite.config.js`, `src/main.jsx`, `src/App.jsx`, `src/data.js`, `src/style.css`, `README.md`.
